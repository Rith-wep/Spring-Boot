package com.ecommerce.project.exceptions;

import java.util.function.Supplier;

public class ResourceNotFoundException extends RuntimeException {
    String resourceName;
    String filed;
    String fieldName;
    Long filedId;

    public ResourceNotFoundException(String resourceName, String filed, String fieldName) {
        super(String.format("%s not found with %s : %s", resourceName, filed, fieldName));
        this.resourceName = resourceName;
        this.filed = filed;
        this.fieldName = fieldName;
    }
    public ResourceNotFoundException(String resourceName, String filed, Long filedId) {
        super(String.format("%s not found with %s : %d", resourceName, filed, filedId));
        this.resourceName = resourceName;
        this.filed = filed;
        this.filedId = filedId;
    }
}
