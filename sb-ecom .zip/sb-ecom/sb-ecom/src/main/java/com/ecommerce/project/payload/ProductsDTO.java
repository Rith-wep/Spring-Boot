package com.ecommerce.project.payload;

import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ProductsDTO {
    private Long productId;
    private String productName;
    private String productDescription;
    private String productImageUrl;
    private Double productPrice;
    private Integer productQuantity;
    private Double specialPrice;
}
