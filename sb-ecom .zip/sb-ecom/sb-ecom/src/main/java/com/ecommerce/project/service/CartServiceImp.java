package com.ecommerce.project.service;

import com.ecommerce.project.exceptions.ApiException;
import com.ecommerce.project.exceptions.ResourceNotFoundException;
import com.ecommerce.project.model.Cart;
import com.ecommerce.project.model.CartItem;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.payload.CartDTO;
import com.ecommerce.project.payload.ProductsDTO;
import com.ecommerce.project.repository.CartItemRepository;
import com.ecommerce.project.repository.CartRepository;
import com.ecommerce.project.repository.ProductsRepository;
import com.ecommerce.project.utils.AuthUtil;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CartServiceImp implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductsRepository productsRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    AuthUtil authUtil;

    @Override
    public CartDTO addProductToCart(Long productId, Integer quantity) {

        Cart cart = createCart();

        Product product = productsRepository.findById(productId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Product", "productId", productId));

        CartItem existingCartItem =
                cartItemRepository.findCartItemByProductIdAndCartId(
                        productId,
                        cart.getCartId()
                );

        if (existingCartItem != null) {
            throw new ApiException("Product already exists in cart");
        }

        if (product.getProductQuantity() == 0) {
            throw new ApiException(product.getProductName() + " is not available");
        }

        if (product.getProductQuantity() < quantity) {
            throw new ApiException(
                    "Please order quantity less than or equal to " +
                            product.getProductQuantity()
            );
        }

        CartItem newCartItem = new CartItem();
        newCartItem.setProduct(product);
        newCartItem.setCart(cart);
        newCartItem.setQuantity(quantity);
        newCartItem.setDiscount(product.getProductDiscount());
        newCartItem.setProductPrice(product.getSpecialPrice());

        cartItemRepository.save(newCartItem);

        // Reduce stock
        product.setProductQuantity(product.getProductQuantity());
        productsRepository.save(product);

        // Sync cart
        cart.getCartItems().add(newCartItem);
        cart.setTotalPrice(
                cart.getTotalPrice() + product.getSpecialPrice() * quantity
        );
        cartRepository.save(cart);

        CartDTO cartDTO = modelMapper.map(cart, CartDTO.class);

        List<ProductsDTO> products = cart.getCartItems().stream()
                .map(item -> {
                    ProductsDTO dto =
                            modelMapper.map(item.getProduct(), ProductsDTO.class);
                    dto.setProductQuantity(item.getQuantity());
                    return dto;
                })
                .collect(Collectors.toList());

        cartDTO.setProducts(products);
        return cartDTO;
    }




    private Cart createCart() {
        Cart userCart = cartRepository.findCartByEmail(authUtil.loggedInEmail());
        if (userCart != null) {
            return userCart;
        }
        Cart cart = new Cart();
        cart.setTotalPrice(0.00);
        cart.setUser(authUtil.LoggedInUser());
        return cartRepository.save(cart);
    }

    @Override
    @Transactional
    public List<CartDTO> getAllCarts() {

        List<Cart> carts = cartRepository.findAll();

        if (carts.isEmpty()) {
            throw new ApiException("No carts found");
        }

        return carts.stream()
                .map(cart -> {
                    CartDTO cartDTO = modelMapper.map(cart, CartDTO.class);

                    List<ProductsDTO> products = cart.getCartItems().stream()
                            .map(item -> {
                                ProductsDTO dto =
                                        modelMapper.map(item.getProduct(), ProductsDTO.class);
                                dto.setProductQuantity(item.getQuantity());
                                return dto;
                            })
                            .collect(Collectors.toList());

                    cartDTO.setProducts(products);
                    return cartDTO;
                })
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public CartDTO getCart(String emailId, Long cartId) {

        Cart cart = cartRepository.findCartByEmailAndCartId(emailId, cartId);
        if (cart == null) {
            throw new ResourceNotFoundException("Cart", "cartId", cartId);
        }

        CartDTO cartDTO = modelMapper.map(cart, CartDTO.class);

        List<ProductsDTO> products = cart.getCartItems().stream()
                .map(item -> {
                    ProductsDTO dto =
                            modelMapper.map(item.getProduct(), ProductsDTO.class);
                    dto.setProductQuantity(item.getQuantity()); // cart quantity
                    return dto;
                })
                .collect(Collectors.toList());

        cartDTO.setProducts(products);
        return cartDTO;
    }


    @Transactional
    @Override
    public CartDTO updateProductQuantityInCart(Long productId, int newQuantity) {

        String emailId = authUtil.loggedInEmail();
        Cart cart = cartRepository.findCartByEmail(emailId);

        Product product = productsRepository.findById(productId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Product", "productId", productId));

        CartItem cartItem = cartItemRepository
                .findCartItemByProductIdAndCartId(cart.getCartId(), productId);

        if (cartItem == null) {
            throw new ResourceNotFoundException("CartItem", "productId", productId);
        }

        // 🔥 FIX: treat newQuantity as DELTA
        int currentQty = cartItem.getQuantity();
        int finalQuantity = currentQty + newQuantity;   // <-- CORE FIX
        int diff = finalQuantity - currentQty;

        if (finalQuantity < 0) {
            throw new ApiException("Quantity cannot be negative");
        }

        if (diff > 0 && product.getProductQuantity() < diff) {
            throw new ApiException("Not enough stock");
        }

        // Update stock
        product.setProductQuantity(product.getProductQuantity() - diff);

        // Update cart total
        cart.setTotalPrice(
                cart.getTotalPrice() + diff * product.getSpecialPrice()
        );

        if (finalQuantity == 0) {
            cart.getCartItems().remove(cartItem);
            cartItemRepository.delete(cartItem);
        } else {
            cartItem.setQuantity(finalQuantity);
        }

        CartDTO cartDTO = modelMapper.map(cart, CartDTO.class);

        List<ProductsDTO> products = cart.getCartItems().stream()
                .map(item -> {
                    ProductsDTO dto =
                            modelMapper.map(item.getProduct(), ProductsDTO.class);
                    dto.setProductQuantity(item.getQuantity());
                    return dto;
                })
                .collect(Collectors.toList());

        cartDTO.setProducts(products);
        return cartDTO;
    }



    @Override
    @Transactional
    public String deleteProductFromCart(Long cartId, Long productId) {

        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Cart", "cartId", cartId));

        CartItem cartItem =
                cartItemRepository.findCartItemByProductIdAndCartId(cartId, productId);

        if (cartItem == null) {
            throw new ResourceNotFoundException("CartItem", "productId", productId);
        }

        // Restore product stock
        Product product = cartItem.getProduct();
        product.setProductQuantity(
                product.getProductQuantity() + cartItem.getQuantity()
        );
        productsRepository.save(product);

        // Update cart total
        cart.setTotalPrice(
                cart.getTotalPrice() -
                        (cartItem.getProductPrice() * cartItem.getQuantity())
        );

        // Sync cart
        cart.getCartItems().remove(cartItem);

        // Delete cart item
        cartItemRepository.delete(cartItem);

        return "Product " + product.getProductName() + " has been deleted from cart";
    }

    @Override
    @Transactional
    public void updateProductInCarts(Long cartId, Long productId) {

        Cart cart = cartRepository.findById(cartId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Cart", "cartId", cartId));

        Product product = productsRepository.findById(productId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Product", "productId", productId));

        CartItem cartItem =
                cartItemRepository.findCartItemByProductIdAndCartId(cartId, productId);

        if (cartItem == null) {
            throw new ApiException(
                    "Product " + product.getProductName() + " not available in cart"
            );
        }

        // 🔥 FIX 1: update cart item price with NEW product price
        cartItem.setProductPrice(product.getSpecialPrice());

        // 🔥 FIX 2: recalculate cart total correctly
        double total = cart.getCartItems().stream()
                .mapToDouble(item ->
                        item.getProductPrice() * item.getQuantity()
                )
                .sum();

        cart.setTotalPrice(total);
    }



}
