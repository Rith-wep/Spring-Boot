package com.ecommerce.project.payload;


import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderDTO {

    private Long orderId;
    private String email;
    private List<OrderItemDTO> items;
    private LocalDateTime orderDate;
    private PaymentAdminDTO payment;
    private Double totalPrice;
    private String orderStatus;
    private Long addressId;
}
