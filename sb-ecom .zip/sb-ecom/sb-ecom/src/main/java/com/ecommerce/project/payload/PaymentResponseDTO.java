package com.ecommerce.project.payload;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PaymentResponseDTO {

    private String paymentMethod;
    private String status;
    private String gateway;
}

