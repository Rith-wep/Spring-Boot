package com.ecommerce.project.payload;

public class CartItemDTO {
    private Long cartItemId;
    private CartDTO cart;
    private ProductsDTO products;
    private Integer quantity;
    private double discount;
    private double productPrice;
}
