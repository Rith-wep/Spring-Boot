package com.ecommerce.project.service;

import com.ecommerce.project.exceptions.ApiException;
import com.ecommerce.project.exceptions.ResourceNotFoundException;
import com.ecommerce.project.model.Cart;
import com.ecommerce.project.model.Category;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.payload.CartDTO;
import com.ecommerce.project.payload.ProductsDTO;
import com.ecommerce.project.payload.ProductsResponse;
import com.ecommerce.project.repository.CartRepository;
import com.ecommerce.project.repository.CategoryRepository;
import com.ecommerce.project.repository.ProductsRepository;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductsServiceImp implements ProductService{

    @Autowired
    private CartService cartService;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductsRepository productsRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    private FileImage fileImage;

    @Value("${project.image}")
    private String path;

// Creating Products

    @Override
    public ProductsDTO addProduct(Long categoryId, ProductsDTO productsDTO) {

        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category", "categoryId", categoryId));

        boolean isProductNotPresent = true;

        List<Product> products = category.getProducts();

        for (Product product : products) {
            if (product.getProductName().equals(productsDTO.getProductName())) {
                isProductNotPresent = false;
                break;
            }
        }

        if (isProductNotPresent) {
            Product product = modelMapper.map(productsDTO, Product.class);
            product.setProductImageUrl("default.png");
            product.setCategory(category);

            double specialPrice = product.getProductPrice() -
                    ((product.getProductDiscount() * 0.01) * product.getProductPrice());
            product.setSpecialPrice(specialPrice);

            Product savedProduct = productsRepository.save(product);
            return modelMapper.map(savedProduct, ProductsDTO.class);
        }else{
            throw new ApiException("Product Already Exists");
        }

    }

// Getting all products

    @Override
    public ProductsResponse getAll(Integer pageNumber, Integer pageSize, String sortBy, String sortOrder) {

        Sort sortOrderBy = sortOrder.equalsIgnoreCase("asc") ?
            Sort.by(sortBy).ascending():
            Sort.by(sortBy).descending();

        Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sortOrderBy);
        Page<Product> productPage = productsRepository.findAll(pageDetails);


        List<Product> products = productPage.getContent();

        List<ProductsDTO> productsDTOS = products.stream()
                .map(product -> modelMapper.map(product, ProductsDTO.class))
                .toList();
        ProductsResponse productsResponse = new ProductsResponse();
        productsResponse.setPageNumber(productPage.getNumber());
        productsResponse.setPageSize(productPage.getSize());
        productsResponse.setTotalPages(productPage.getTotalPages());
        productsResponse.setTotalElements(productPage.getTotalElements());
        productsResponse.setLastPage(productPage.isLast());
        productsResponse.setContent(productsDTOS);
        return productsResponse;
    }

// Searching By Category

    @Override
    public ProductsResponse searchByCategory(Long categoryId, Integer pageNumber, Integer pageSize, String sortBy, String sortOrder) {
        Category category = categoryRepository.findById(categoryId)
            .orElseThrow(() -> new ResourceNotFoundException("Category", "categoryId", categoryId));

        Sort sort = sortOrder.equalsIgnoreCase("asc") ?
        Sort.by(sortBy).ascending():
        Sort.by(sortBy).descending();

        Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sort);
        Page<Product> productsPage = productsRepository.findByCategory(category, pageDetails);
        List<Product> products = productsPage.getContent();
        List<ProductsDTO> productsDTOS = products.stream()
                .map(product -> modelMapper.map(product, ProductsDTO.class))
                .toList();

        ProductsResponse productsResponse = new ProductsResponse();
        productsResponse.setPageNumber(productsPage.getNumber());
        productsResponse.setPageSize(productsPage.getSize());
        productsResponse.setTotalPages(productsPage.getTotalPages());
        productsResponse.setTotalElements(productsPage.getTotalElements());
        productsResponse.setLastPage(productsResponse.isLastPage());
        productsResponse.setContent(productsDTOS);
        return productsResponse;
    }

// Getting by keyword

    @Override
    public ProductsResponse getByKeyword(String keyword, Integer pageNumber,  Integer pageSize, String sortBy, String sortOrder) {

        Sort sort = sortOrder.equalsIgnoreCase("asc") ?
            Sort.by(sortBy).ascending():
            Sort.by(sortBy).descending();

        Pageable pageDetail = PageRequest.of(pageNumber, pageSize, sort);
        Page<Product> productPage = productsRepository.findByProductNameContainingIgnoreCase(keyword, pageDetail);

        if (productPage.isEmpty()){
            throw new ResourceNotFoundException("Product", "keyword", keyword);
        }

        List<Product> productList = productPage.getContent();
        List<ProductsDTO> productsDTOS = productList.stream()
                .map(product -> modelMapper.map(product, ProductsDTO.class))
                .toList();

        ProductsResponse productsResponse = new ProductsResponse();
        productsResponse.setPageNumber(productPage.getNumber());
        productsResponse.setPageSize(productPage.getSize());
        productsResponse.setTotalPages(productPage.getTotalPages());
        productsResponse.setTotalElements(productPage.getTotalElements());
        productsResponse.setLastPage(productsResponse.isLastPage());
        productsResponse.setContent(productsDTOS);
        return productsResponse;
    }

// Updating Product

    @Override
    public ProductsDTO updateProduct(Long productId, ProductsDTO productsDTO) {

        Product productExisting = productsRepository.findById(productId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Product", "ProductId", productId));

        Product product = modelMapper.map(productsDTO, Product.class);

        productExisting.setProductName(product.getProductName());
        productExisting.setProductPrice(product.getProductPrice());
        productExisting.setProductDescription(product.getProductDescription());
        productExisting.setProductDiscount(product.getProductDiscount());
        productExisting.setProductQuantity(product.getProductQuantity());

        double specialPrice = product.getProductPrice()
                - ((product.getProductDiscount() * 0.01) * product.getProductPrice());

        productExisting.setSpecialPrice(specialPrice);

        Product savedProduct = productsRepository.save(productExisting);

        List<Cart> carts = cartRepository.findCartByProductId(productId);
        carts.forEach(cart ->
                cartService.updateProductInCarts(cart.getCartId(), productId)
        );

        return modelMapper.map(savedProduct, ProductsDTO.class);
    }


// Deleting Product

    @Transactional
    @Override
    public String deleteProduct(Long productsId) {

        Product product = productsRepository.findById(productsId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Product", "ProductId", productsId));

        List<Cart> carts = cartRepository.findCartByProductId(productsId);

        carts.forEach(cart ->
                cartService.deleteProductFromCart(cart.getCartId(), productsId)
        );

        productsRepository.delete(product);

        return "Deleted successfully";
    }


    @Override
    public ProductsDTO updateProductImage(Long productId, MultipartFile image) throws IOException {
        Product IsProductExist = productsRepository.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product", "ProductId", productId));
        String fileName = fileImage.uploadImage(path, image);
        IsProductExist.setProductImageUrl(fileName);
        Product savedProduct = productsRepository.save(IsProductExist);
        return modelMapper.map(savedProduct, ProductsDTO.class);
    }


}
