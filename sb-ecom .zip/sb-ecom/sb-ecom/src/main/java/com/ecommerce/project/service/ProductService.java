package com.ecommerce.project.service;

import com.ecommerce.project.payload.ProductsDTO;
import com.ecommerce.project.payload.ProductsResponse;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface ProductService {
    ProductsDTO addProduct(Long categoryId, ProductsDTO productsDTO);

    ProductsResponse getAll(Integer pageNumber, Integer pageSize,  String sortBy, String sortOrder);

    ProductsResponse searchByCategory(Long categoryId, Integer pageNumber, Integer pageSize ,String sortBy, String sortOrder);

    ProductsResponse getByKeyword(String keyword, Integer pageNumber, Integer pageSize, String sortBy, String sortOrder);

    ProductsDTO updateProduct(Long productId, ProductsDTO productsDTO);

    String deleteProduct(Long productsId);

    ProductsDTO updateProductImage(Long productId, MultipartFile image) throws IOException;
}
