package com.ecommerce.project.security.jwt.response;

import lombok.Getter;

import java.util.List;

@Getter
public class LoginResponse {
    private Long id;
    private String jwtToken;
    private String username;
    private List<String> roles;

    public LoginResponse(Long id, String jwtToken,  String username, List<String> roles) {
        this.id = id;
        this.jwtToken = jwtToken;
        this.username = username;
        this.roles = roles;
    }
    public LoginResponse(Long id,  String username, List<String> roles) {
        this.id = id;
        this.username = username;
        this.roles = roles;
    }
}
