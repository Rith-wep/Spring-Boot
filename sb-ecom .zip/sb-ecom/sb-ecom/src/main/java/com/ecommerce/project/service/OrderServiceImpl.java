package com.ecommerce.project.service;

import com.ecommerce.project.exceptions.ApiException;
import com.ecommerce.project.exceptions.ResourceNotFoundException;
import com.ecommerce.project.model.*;
import com.ecommerce.project.payload.OrderDTO;
import com.ecommerce.project.payload.OrderItemDTO;
import com.ecommerce.project.payload.ProductsDTO;
import com.ecommerce.project.repository.*;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private ProductsRepository productsRepository;

    @Autowired
    private CartService cartService;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    @Transactional
    public OrderDTO placeOrder(String email,
                               Long addressId,
                               String paymentMethod) {

        // 1️⃣ Get cart
        Cart cart = cartRepository.findCartByEmail(email);
        if (cart == null) {
            throw new ResourceNotFoundException("Cart", "email", email);
        }

        if (cart.getCartItems().isEmpty()) {
            throw new ApiException("Cart is empty");
        }

        // 2️⃣ Get address
        Address address = addressRepository.findById(addressId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Address", "addressId", addressId));

        // 3️⃣ Create Order (PAYMENT NOT CONFIRMED YET)
        Order order = new Order();
        order.setEmail(email);
        order.setOrderDate(LocalDateTime.now());
        order.setOrderStatus("PENDING_PAYMENT");
        order.setShippingAddress(address);

        // 4️⃣ Create Payment (INITIAL STATE)
        Payment payment = new Payment();
        payment.setPaymentMethod(paymentMethod);
        payment.setPgStatus("PENDING");

        payment.setOrder(order);
        order.setPayment(payment);

        // save order + payment
        Order savedOrder = orderRepository.save(order);
        paymentRepository.save(payment);

        // 5️⃣ Convert CartItems → OrderItems
        List<OrderItem> orderItems = new ArrayList<>();

        for (CartItem cartItem : cart.getCartItems()) {

            Product product = cartItem.getProduct();
            int quantity = cartItem.getQuantity();

            // 6️⃣ Stock validation
            if (product.getProductQuantity() < quantity) {
                throw new ApiException(
                        "Insufficient stock for product: " + product.getProductName());
            }

            // reduce stock
            product.setProductQuantity(product.getProductQuantity() - quantity);
            productsRepository.save(product);

            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(savedOrder);
            orderItem.setProduct(product);
            orderItem.setQuantity(quantity);
            orderItem.setDiscount(cartItem.getDiscount());
            orderItem.setOrderProductPrice(cartItem.getProductPrice());

            orderItems.add(orderItem);
        }

        orderItemRepository.saveAll(orderItems);

        // 7️⃣ Clear cart
        for (CartItem cartItem : new ArrayList<>(cart.getCartItems())) {
            cartService.deleteProductFromCart(
                    cart.getCartId(),
                    cartItem.getProduct().getProductId()
            );
        }

        // 8️⃣ Prepare response DTO
        OrderDTO orderDTO = modelMapper.map(savedOrder, OrderDTO.class);

        List<OrderItemDTO> itemDTOs = orderItems.stream()
                .map(item -> {
                    OrderItemDTO dto = new OrderItemDTO();
                    dto.setOrderItemId(item.getOrderItemid());

                    ProductsDTO productDTO = new ProductsDTO();
                    productDTO.setProductId(item.getProduct().getProductId());
                    productDTO.setProductName(item.getProduct().getProductName());
                    productDTO.setProductDescription(item.getProduct().getProductDescription());
                    productDTO.setProductImageUrl(item.getProduct().getProductImageUrl());
                    productDTO.setProductPrice(item.getProduct().getProductPrice());
                    productDTO.setProductQuantity(item.getProduct().getProductQuantity());
                    productDTO.setSpecialPrice(item.getProduct().getSpecialPrice());

                    dto.setProduct(productDTO);
                    dto.setQuantity(item.getQuantity());
                    dto.setDiscount(item.getDiscount());
                    dto.setOrderProductPrice(item.getOrderProductPrice());

                    return dto;
                })
                .toList();


        orderDTO.setItems(itemDTOs);
        orderDTO.setAddressId(addressId);

        return orderDTO;
    }
}
