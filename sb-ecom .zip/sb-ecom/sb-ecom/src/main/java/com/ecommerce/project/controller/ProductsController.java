package com.ecommerce.project.controller;


import com.ecommerce.project.config.AppConstants;
import com.ecommerce.project.payload.ProductsDTO;
import com.ecommerce.project.payload.ProductsResponse;
import com.ecommerce.project.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api")
public class ProductsController {

    @Autowired
    private ProductService productService;

    @PostMapping("/admin/categories/{categoryId}/product")
    public ResponseEntity<ProductsDTO> addProduct(
        @Valid
        @RequestBody ProductsDTO productsDTO,
        @PathVariable Long categoryId
         ) {
         ProductsDTO products = productService.addProduct(categoryId, productsDTO);
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @GetMapping("/public/product")
    public ResponseEntity<ProductsResponse> getAllProducts(
        @RequestParam(name = "pageNumber", defaultValue = AppConstants.PAGE_NUMBER) Integer pageNumber,
        @RequestParam(name = "pageSize", defaultValue = AppConstants.PAGE_SIZE) Integer pageSize,
        @RequestParam(name = "sortBy", defaultValue = AppConstants.SORT_PRODUCT_BY) String sortBy,
        @RequestParam(name = "sortOrder", defaultValue = AppConstants.sortOrder) String sortOrder

    ) {
        ProductsResponse productsResponse = productService.getAll(pageNumber, pageSize,  sortBy, sortOrder);
        return new ResponseEntity<>(productsResponse, HttpStatus.OK);
    }

    @GetMapping("/public/categories/{categoryId}/product")
    public ResponseEntity<ProductsResponse> getByCategory(
        @PathVariable Long categoryId,
        @RequestParam(name = "pageNumber", defaultValue = AppConstants.PAGE_NUMBER) Integer pageNumber,
        @RequestParam(name = "pageSize", defaultValue = AppConstants.PAGE_SIZE) Integer pageSize,
        @RequestParam(name = "sortBy", defaultValue = AppConstants.SORT_PRODUCT_BY) String sortBy,
        @RequestParam(name = "sortOrder", defaultValue = AppConstants.sortOrder) String sortOrder
        ) {
        ProductsResponse productsResponse = productService.searchByCategory(categoryId, pageNumber, pageSize, sortBy, sortOrder);

        return new ResponseEntity<>(productsResponse, HttpStatus.OK);
    }

    @GetMapping("/public/products/keyword")
    public ResponseEntity<ProductsResponse> getProductByKeyword(
        @RequestParam String keyword,
        @RequestParam(name = "pageNumber", defaultValue = AppConstants.PAGE_NUMBER) Integer pageNumber,
        @RequestParam(name = "pageSize", defaultValue = AppConstants.PAGE_SIZE) Integer pageSize,
        @RequestParam(name = "sortBy", defaultValue = AppConstants.SORT_PRODUCT_BY) String sortBy,
        @RequestParam(name = "sortOrder", defaultValue = AppConstants.sortOrder) String sortOrder
        ){
        ProductsResponse productsResponse = productService.getByKeyword(keyword, pageNumber, pageSize,sortBy, sortOrder);
        return new ResponseEntity<>(productsResponse, HttpStatus.OK);
    }

    @PutMapping("/admin/products/{productId}")
    public ResponseEntity<ProductsDTO> updateProduct(
        @Valid
        @PathVariable Long productId,
        @RequestBody ProductsDTO productsDTO
    ){
        ProductsDTO products = productService.updateProduct(productId, productsDTO);
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @DeleteMapping("/admin/products/{productsId}")
    public ResponseEntity<String> deleteProduct(@PathVariable Long productsId){
        String message = productService.deleteProduct(productsId);
        return ResponseEntity.ok(message);
    }

    @PutMapping("/products/{productId}/image")
    public ResponseEntity<ProductsDTO> updateProductImage(
        @PathVariable Long productId,
        @RequestParam("Image") MultipartFile image) throws IOException {

        ProductsDTO updateProduct = productService.updateProductImage(productId, image);
        return new ResponseEntity<>(updateProduct ,HttpStatus.OK);
    }
}
